# MCQ-Generator-using-AI-Auto-Create-Questions-from-Text-Files-Flask-Web-App-Tutorial


In this tutorial, you'll learn how to create a Flask web app that automatically generates multiple-choice questions (MCQs) from text files using Google Generative AI. We'll demonstrate file handling for PDFs, DOCX, and TXT formats, and show how to generate and download the MCQs in both text and PDF formats. Perfect for educators and developers alike!


MCQ generator, AI MCQ creation, Flask tutorial, Google generative AI, Python web app, file handling in Flask, MCQ from text files, pdf docx txt extraction, Flask project, Google AI API, automatic question generation, Flask file upload, Flask app tutorial, generate MCQs, Python PDF creation, Flask Google API integration
